package co.edu.campusucc.sd.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;


import co.edu.campusucc.sd.daos.EmpleadosDAO;

import co.edu.campusucc.sd.modelo.Empleados;

class EmpleadosTest {

	@Test
	void test() {
		EmpleadosDAO dao = new EmpleadosDAO();
		Empleados em = new Empleados();

	    em.setFechaGiro("10/12/20");
	    em.setIdEmpleado("98");
	    


		try {
			dao.persist(em);
			assertTrue(true);

		} catch (Exception e) {

			fail(e.toString());

		}

	}
}