package co.edu.campusucc.sd.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import co.edu.campusucc.sd.daos.ClienteDAO;
import co.edu.campusucc.sd.modelo.Cliente;

class ClienteTest {

	@Test
	void test() {
		ClienteDAO dao = new ClienteDAO();
		Cliente cl = new Cliente();

		cl.setNombres("tony");
		cl.setIdTipoDocumento("1144212791");
		cl.setIdUbicacion("Mexico");
		cl.setRazonSocial("Estudio");

		try {
			dao.persist(cl);
			assertTrue(true);

		} catch (Exception e) {

			fail(e.toString());

		}

	}

}