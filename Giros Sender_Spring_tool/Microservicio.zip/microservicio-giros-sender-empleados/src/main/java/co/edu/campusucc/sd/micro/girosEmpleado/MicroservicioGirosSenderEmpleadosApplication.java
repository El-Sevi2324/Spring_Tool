package co.edu.campusucc.sd.micro.girosEmpleado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicioGirosSenderEmpleadosApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicioGirosSenderEmpleadosApplication.class, args);
	}

}
