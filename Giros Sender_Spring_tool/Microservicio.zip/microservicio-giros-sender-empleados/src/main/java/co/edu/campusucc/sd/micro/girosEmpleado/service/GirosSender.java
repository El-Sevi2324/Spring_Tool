package co.edu.campusucc.sd.micro.girosEmpleado.service;

import co.edu.campusucc.sd.modelo.Empleados;

public interface GirosSender {
	
	Empleados crearEmpleados(String idEmpleado, String  fechaGiro);

}
