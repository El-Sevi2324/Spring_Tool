package co.edu.campusucc.sd.micro.girosEmpleado.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import co.edu.campusucc.sd.micro.girosEmpleado.service.GirosSender;
import co.edu.campusucc.sd.modelo.Empleados;

@RestController
public class GiroSenderControllers {
	@Autowired
	private GirosSender girosender;
	@GetMapping("/crearEmpleado/fechagiros/{fechaGiro}/idempleado/{IdEmpleado}")
	public Empleados giroEmpleados(@PathVariable String fechaGiro, @PathVariable String idEmpleado) {
		return girosender.crearEmpleados(fechaGiro,idEmpleado);
	}

}
