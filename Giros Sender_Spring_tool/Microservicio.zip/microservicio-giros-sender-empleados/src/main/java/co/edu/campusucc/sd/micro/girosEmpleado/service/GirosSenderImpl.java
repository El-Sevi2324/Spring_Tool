package co.edu.campusucc.sd.micro.girosEmpleado.service;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import org.springframework.stereotype.Component;

import co.edu.campusucc.sd.daos.EmpleadosDAO;
import co.edu.campusucc.sd.modelo.Empleados;

@Component
public class GirosSenderImpl implements GirosSender {

	@Override
	public Empleados crearEmpleados(String idEmpleado, String fechaGiro) {
		EmpleadosDAO dao = new EmpleadosDAO();
		Empleados em = new Empleados();

		em.setFechaGiro(fechaGiro);
		em.setIdEmpleado(idEmpleado);

		try {
			dao.persist(em);
			System.out.println("vale");

		} catch (Exception e) {

			System.out.println(e.toString());

		}
		return null;
	}
}